<!-- Pie de página -->
<footer class="bg-secondary text-white text-center py-3 mt-5">
    <p>&copy; 2024 Mi Proyecto - Todos los derechos reservados</p>
</footer>

<!-- Bootstrap JavaScript -->
<script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>